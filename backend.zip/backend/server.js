const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const mysql = require('mysql2');

const app = express();
const port = 5000;

// Middleware
app.use(cors());
app.use(bodyParser.json());

// MySQL Connection
require('dotenv').config();

const db = mysql.createConnection({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
});

db.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL:', err);
  } else {
    console.log('Connected to MySQL database');
  }
});

// Create todos table (if it doesn't exist)
const createTodosTable = () => {
  const query = `
    CREATE TABLE IF NOT EXISTS todos (
      id INT AUTO_INCREMENT PRIMARY KEY,
      title VARCHAR(255) NOT NULL,
      priority ENUM('High', 'Medium', 'Low') DEFAULT 'Medium',
      start_time DATETIME,
      end_time DATETIME,
      category VARCHAR(255),
      completed BOOLEAN DEFAULT false
    )
  `;

  db.query(query, (err) => {
    if (err) {
      console.error('Error creating todos table:', err);
    }
  });
};

createTodosTable();

// Fetch all todos
app.get('/api/todos', (req, res) => {
  const query = 'SELECT * FROM todos';
  db.query(query, (err, results) => {
    if (err) {
      console.error('Error fetching todos:', err);
      res.status(500).json({ error: 'Failed to fetch todos' });
    } else {
      res.json(results);
    }
  });
});

// Add a new todo
app.post('/api/todos', (req, res) => {
  const { title, priority, start_time, end_time, category } = req.body;

  if (!title) {
    return res.status(400).json({ error: 'Title is required' });
  }

  const query = `
    INSERT INTO todos (title, priority, start_time, end_time, category)
    VALUES (?, ?, ?, ?, ?)
  `;
  db.query(
    query,
    [title, priority, start_time, end_time, category],
    (err, results) => {
      if (err) {
        console.error('Error adding todo:', err);
        res.status(500).json({ error: 'Failed to add todo' });
      } else {
        res.json({
          id: results.insertId,
          title,
          priority,
          start_time,
          end_time,
          category,
          completed: false,
        });
      }
    }
  );
});

// Update a todo
app.put('/api/todos/:id', (req, res) => {
  const { id } = req.params;
  const { title, priority, start_time, end_time, category, completed } = req.body;

  const query = `
    UPDATE todos
    SET title = ?, priority = ?, start_time = ?, end_time = ?, category = ?, completed = ?
    WHERE id = ?
  `;
  db.query(
    query,
    [title, priority, start_time, end_time, category, completed, id],
    (err, results) => {
      if (err) {
        console.error('Error updating todo:', err);
        res.status(500).json({ error: 'Failed to update todo' });
      } else {
        res.json({ id, title, priority, start_time, end_time, category, completed });
      }
    }
  );
});

// Delete a todo
app.delete('/api/todos/:id', (req, res) => {
  const { id } = req.params;

  const query = 'DELETE FROM todos WHERE id = ?';
  db.query(query, [id], (err, results) => {
    if (err) {
      console.error('Error deleting todo:', err);
      res.status(500).json({ error: 'Failed to delete todo' });
    } else {
      res.json({ id });
    }
  });
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});